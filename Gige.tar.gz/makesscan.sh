#!/bin/bash
mkdir ~/Apps/epics/modules
tar -zxvf  sscan_R2-11-3.tar.gz -C ~/Apps/epics/modules
cd ~/Apps/epics/modules
ln -s sscan-2-11-3 sscan
cd sscan/configure
user=$(whoami)
sed -i 's/EPICS_BASE=/#EPICS_BASE=/g' RELEASE
sed -i 's/SUPPORT=/#SUPPORT=/g' RELEASE
sed -i 's/sscan/sscan/g' RELEASE
echo "EPICS_BASE=/usr/local/epics/base" >> RELEASE
echo "SUPPORT=/home/"$user"/Apps/epics/modules" >> RELEASE
cd ..
make
