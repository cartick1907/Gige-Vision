#!/bin/bash
mkdir ~/Apps/epics/modules
tar -zxvf  busy_R1-7-2.tar.gz -C ~/Apps/epics/modules
cd ~/Apps/epics/modules
ln -s busy-1-7-2 busy
cd busy/configure
user=$(whoami)
sed -i 's/EPICS_BASE=/#EPICS_BASE=/g' RELEASE
sed -i 's/SUPPORT=/#SUPPORT=/g' RELEASE
sed -i 's/asyn-4-17/asyn/g' RELEASE
echo "EPICS_BASE=/usr/local/epics/base" >> RELEASE
echo "SUPPORT=/home/"$user"/Apps/epics/modules" >> RELEASE
cd ..
make
