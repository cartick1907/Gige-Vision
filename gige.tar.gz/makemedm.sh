#!/bin/bash
cd ~/Apps/epics/
git clone https://github.com/jeonghanlee/extensions
sudo apt-get install build-essential libmotif-dev
sudo apt-get install x11proto-print-dev xfonts-100dpi
sudo apt-get install libxmu-dev libxpm-dev
sudo sh -c "echo \"deb http://security.ubuntu.com/ubuntu precise-security main\" >> /etc/apt/sources.list"
echo | sudo add-apt-repository ppa:zeehio/libxp 
sudo apt-get update
sudo apt-get install libxp-dev libxp6
cp /usr/lib/x86_64-linux-gnu/libXm.a ~/Apps/epics/base/lib/linux-x86_64/
cp /usr/lib/x86_64-linux-gnu/libXt.a ~/Apps/epics/base/lib/linux-x86_64/
cp /usr/lib/x86_64-linux-gnu/libXp.a ~/Apps/epics/base/lib/linux-x86_64/
cp /usr/lib/x86_64-linux-gnu/libXmu.a ~/Apps/epics/base/lib/linux-x86_64/
cp /usr/lib/x86_64-linux-gnu/libXext.a ~/Apps/epics/base/lib/linux-x86_64/
cp /usr/lib/x86_64-linux-gnu/libX11.a ~/Apps/epics/base/lib/linux-x86_64/
sudo apt-get install libc6-dev
cp /usr/lib/x86_64-linux-gnu/libdl.a ~/Apps/epics/base/lib/linux-x86_64/
cd ~/Apps/epics/extensions
bash init.bash
bash patch_3.16.bash 
cd ~/Apps/epics/extensions/src/medm
make  
cd /etc/X11/fonts/misc
sudo wget https://epics.anl.gov/EpicsDocumentation/ExtensionsManuals/MEDM/medmfonts.ali.txt
sudo mv medmfonts.ali.txt medm.alias
sudo update-fonts-alias misc
echo | sudo add-apt-repository --remove ppa:zeehio/libxp

