tar -zxvf autosave-R5-10-2.tar.gz  -C ~/Apps/epics/modules/
cd ~/Apps/epics/modules
ln -s autosave-R5-10-2/ autosave
cd ~/Apps/epics/modules/autosave
cd configure
sed -i 's/EPICS_BASE=/#EPICS_BASE=/g' RELEASE
sed -i 's/SUPPORT=/#SUPPORT=/g' RELEASE
echo "EPICS_BASE=/usr/local/epics/base" >>RELEASE
cd ..
make
