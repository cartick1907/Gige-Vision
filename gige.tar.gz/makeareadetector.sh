user=$(whoami)
tar -xf areaDetector.tar.gz -C ~/Apps/epics/modules/
cd ~/Apps/epics/modules/
cd areaDetector/configure
cp EXAMPLE_RELEASE.local RELEASE.local
cp EXAMPLE_RELEASE_LIBS.local RELEASE_LIBS.local
cp EXAMPLE_RELEASE_PRODS.local RELEASE_PRODS.local
cp EXAMPLE_CONFIG_SITE.local CONFIG_SITE.local
sed -i 's/EPICS_BASE=/#EPICS_BASE=/g' RELEASE_LIBS.local
sed -i 's/SUPPORT=/#SUPPORT=/g' RELEASE_LIBS.local
sed -i 's/AD#SUPPORT=/ADSUPPORT=/g' RELEASE_LIBS.local
sed -i 's/areaDetector-3-12-1/areaDetector/g' RELEASE_LIBS.local
sed -i 's/asyn-4-42/asyn/g' RELEASE_LIBS.local
echo "EPICS_BASE=/usr/local/epics/base" >> RELEASE_LIBS.local
echo "SUPPORT=/home/"$user"/Apps/epics/modules" >> RELEASE_LIBS.local
sed -i 's/EPICS_BASE=/#EPICS_BASE=/g' RELEASE_PRODS.local
sed -i 's/SUPPORT=/#SUPPORT=/g' RELEASE_PRODS.local
sed -i 's/AD#SUPPORT=/ADSUPPORT=/g' RELEASE_PRODS.local
sed -i 's/areaDetector-3-12-1/areaDetector/g' RELEASE_PRODS.local
sed -i 's/DEVIOCSTATS/#DEVIOCSTATS/g' RELEASE_PRODS.local
sed -i 's/asyn-4-42/asyn/g' RELEASE_PRODS.local
sed -i 's/autosave-5-10/autosave/g' RELEASE_PRODS.local
sed -i 's/busy-1-7-2/busy/g' RELEASE_PRODS.local
sed -i 's/calc-3-7-3/calc/g' RELEASE_PRODS.local
sed -i 's/sscan-2-11-3/sscan/g' RELEASE_PRODS.local
sed -i 's/seq-2-2-5/Seq/g' RELEASE_PRODS.local
echo "EPICS_BASE=/usr/local/epics/base" >> RELEASE_PRODS.local
echo "SUPPORT=/home/"$user"/Apps/epics/modules" >> RELEASE_PRODS.local
sed -i 's/WITH_QSRV = YES/WITH_QSRV = NO/g' CONFIG_SITE.local
#sed -i 's/WITH_PVA  = YES/WITH_PVA = NO/g' CONFIG_SITE.local


sudo apt-get install libx11-dev libxtst-dev
cd ~/Apps/epics/modules/areaDetector/
make
