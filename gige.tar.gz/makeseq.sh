#!/bin/bash
mkdir ~/Apps/epics/modules
tar -zxvf  seq-2.2.5.tar.gz -C ~/Apps/epics/modules
cd ~/Apps/epics/modules
ln -s seq-2.2.5 Seq
cd Seq/configure
sed -i 's/EPICS_BASE=/#EPICS_BASE=/g' RELEASE
sed -i 's/SUPPORT=/#SUPPORT=/g' RELEASE
echo "EPICS_BASE=/usr/local/epics/base" >> RELEASE
user=$(whoami)
echo "SUPPORT=/home/"$user"/Apps/epics/modules" >> RELEASE
cd ..
make
