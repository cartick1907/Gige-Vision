#/bin/bash
sudo apt install gcc
sudo apt install g++
sudo apt install make
sudo apt install qt5-default
sudo apt install re2c xml2 libxml2 git zlib1g-dev libnetcdf-dev libxml2-dev libxml2-dev
sudo apt-get install qtbase5-dev qtchooser qt5-qmake qtbase5-dev-tools
sudo apt install qttools5-dev-tools
sudo apt install libqt5designer5
sudo apt install libqt5x11extras5-dev
sudo apt install qttools5-*
sudo apt install libqt5svg5*
sudo apt install libreadline-dev
