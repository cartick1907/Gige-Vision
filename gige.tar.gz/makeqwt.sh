#!/bin/bash
wget https://sourceforge.net/projects/qwt/files/qwt/6.1.2/qwt-6.1.2.zip
unzip qwt-6.1.2.zip
cd qwt-6.1.2
/usr/lib/x86_64-linux-gnu/qt5/bin/qmake qwt.pro 
make
sudo make install
sudo ln -s /usr/lib/x86_64-linux-gnu/libQt5OpenGL.so.5 /usr/lib/x86_64-linux-gnu/libQt5OpenGL.so
sudo ln -s /usr/lib/libqwt-qt5.so /usr/lib/libqwt.so
wget https://codeload.github.com/caqtdm/caqtdm/zip/refs/tags/V4.4.0
unzip caqtdm-4.4.0.zip
mv caqtdm-4.4.0 ~/Apps/epics/extensions/src/ 
cd ~/Apps/epics/extensions/src/caqtdm-4.4.0/
rm caQtDM_Env
cd ~/EPICS/Gige-Vision
cp caQtDM_Env ~/Apps/epics/extensions/src/caqtdm-4.4.0/
cd ~/Apps/epics/extensions/src/caqtdm-4.4.0/caQtDM_Lib/src
rm caqtdm_lib.cpp
cd ~/EPICS/Gige-Vision
cp caqtdm_lib.cpp ~/Apps/epics/extensions/src/caqtdm-4.4.0/caQtDM_Lib/src
echo | sudo add-apt-repository ppa:ubuntu-toolchain-r/test
sudo apt-get update
sudo apt install gcc-10
sudo apt install g++-10
sudo update-alternatives --install /usr/bin/g++ g++ /usr/bin/g++-10 20
sudo update-alternatives --install /usr/bin/gcc gcc /usr/bin/gcc-10 20
cd ~/Apps/epics/extensions/src/caqtdm-4.4.0/
./caQtDM_BuildAll
cd ../
mkdir -p bin/linux-x86_64
cd ../src/caqtdm-4.4.0/
./caQtDM_Install
