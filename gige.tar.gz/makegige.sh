#!/bin/bash
sudo apt-get install libglib2.0-dev libgtk2.0-dev
sudo apt-get install libstdc++6
sudo cp /usr/lib/x86_64-linux-gnu/glib-2.0/include/glibconfig.h /usr/include/glib-2.0/glibconfig.h
cd ~/Apps/epics/modules/areaDetector/configure
sed -i 's/GLIB_INCLUDE =/#GLIB_INCLUDE =/g' CONFIG_SITE.local
sed -i 's/glib-2.0_DIR =/#glib-2.0_DIR =/g' CONFIG_SITE.local
echo "GLIB_INCLUDE=/usr/include/glib-2.0" >> CONFIG_SITE.local
echo "glib-2.0_DIR=/usr/lib/x86_64-linux-gnu/" >> CONFIG_SITE.local
cd ~/Apps/epics/modules/areaDetector/aravisGigE/
./install.sh
sudo apt-get install libusb-1.0-0-dev libglibmm-2.4-dev
make
user=$(whoami)
echo "export EPICS_CA_AUTO_ADDR_LIST=NO" >> ~/.bash_aliases
echo "export EPICS_CA_ADDR_LIST=192.168.4.115" >> ~/.bash_aliases
echo "export EPICS_DISPLAY_PATH=/home/"$user"/Apps/epics/modules/areaDetector/ADCore/ADApp/op/adl:/home/"$user"/Apps/epics/modules/areaDetector/NDDriverStdArrays/NDDriverStdArraysApp/op/adl:/home/"$user"/Apps/epics/modules/areaDetector/pvaDriver/pvaDriverApp/op/adl:/home/"$user"/Apps/epics/modules/areaDetector/ADPvCam/pvcamApp/op/adl:/home/"$user"/Apps/epics/modules/areaDetector/aravisGigE/aravisGigEApp/op/adl:/home/"$user"/Apps/epics/modules/areaDetector/ADGenICam/GenICamApp/op/adl:/home/"$user"/Apps/epics/modules/areaDetector/ffmpegServer/ffmpegServerApp/op/adl:/home/"$user"/Apps/epics/modules/areaDetector/ADSimDetector/simDetectorApp/op/adl:/home/"$user"/Apps/epics/modules/areaDetector/ADQImaging/App/op/adl:/home/"$user"/Apps/epics/modules/areaDetector/ADPluginEdge/edgeApp/op/adl:/home/"$user"/Apps/epics/modules/areaDetector/ADAravis/aravisApp/op/adl:/home/"$user"/Apps/epics/modules/asyn/opi/medm:/home/"$user"/Apps/epics/modules/asyn/testApp/adl:/home/"$user"/Apps/epics/modules/asyn/testArrayRingBufferApp/adl:/home/"$user"/Apps/epics/modules/asyn/testAsynPortDriverApp/adl:/home/"$user"/Apps/epics/modules/asyn/testEpicsApp/adl:/home/"$user"/Apps/epics/modules/asyn/testErrorsApp/adl:/home/"$user"/Apps/epics/modules/asyn/testGpibApp/adl:/home/"$user"/Apps/epics/modules/asyn/testIPServerApp/adl:/home/"$user"/Apps/epics/modules/asyn/testOutputCallbackApp/adl:/home/"$user"/Apps/epics/modules/autosave/asApp/op/adl:/home/"$user"/Apps/epics/modules/busy/busyApp/op/adl:/home/"$user"/Apps/epics/modules/calc/calcApp/op/adl:/home/"$user"/Apps/epics/modules/seq/examples/cmdButtons:/home/"$user"/Apps/epics/modules/seq/examples/demo:/home/"$user"/Apps/epics/modules/sscan/sscanApp/op/adl" >> ~/.bash_aliases
echo "export EPICS_CA_MAX_ARRAY_BYTES=50000000" >> ~/.bash_aliases
echo "export PATH=${PATH}:/usr/local/epics/extensions/bin/${EPICS_HOST_ARCH}" >> ~/.bash_aliases
