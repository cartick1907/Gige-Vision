sudo apt-get install libglib2.0-dev libgtk2.0-dev
sudo apt-get install libstdc++6
sudo cp /usr/lib/x86_64-linux-gnu/glib-2.0/include/glibconfig.h /usr/include/glib-2.0/glibconfig.h
cd ~/Apps/epics/modules/areaDetector/configure
sed -i 's/GLIB_INCLUDE =/#GLIB_INCLUDE =/g' CONFIG_SITE.local
sed -i 's/glib-2.0_DIR =/#glib-2.0_DIR =/g' CONFIG_SITE.local
echo "GLIB_INCLUDE=/usr/include/glib-2.0" >> CONFIG_SITE.local
echo "glib-2.0_DIR=/usr/lib/x86_64-linux-gnu/" >> CONFIG_SITE.local
cd ~/Apps/epics/modules/areaDetector/aravisGigE/
./install.sh
sudo apt-get install libusb-1.0-0-dev libglibmm-2.4-dev
make

