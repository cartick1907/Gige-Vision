#!/bin/bash
sudo apt-get install default-jre
wget https://wsr.imagej.net/distros/linux/ij153-linux64-java8.zip
mkdir ~/Apps/epics/ImageJ
unzip ij*.zip -d ~/Apps/epics/ImageJ
user=$(whoami)
echo "alias imagej=/home/<user>/Apps/epics/ImageJ/ImageJ/ImageJ" >> ~/.bash_aliases
cp -r ~/Apps/epics/modules/areaDetector/ADViewers/ImageJ/EPICS_areaDetector ~/Apps/epics/ImageJ/plugins
