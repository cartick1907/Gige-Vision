#!/bin/bash
basedir=$(pwd)
base=~/Apps/epics/base
packages_present=()
packages_left=()
if [ -e "$base" ]; then
    packages_present+=("base")
else
    packages_left+=("base")
fi
asyn=~/Apps/epics/modules/asyn
if [ -e "$asyn" ]; then
    packages_present+=("asyn")
else
    packages_left+=("asyn")
fi
auto=~/Apps/epics/modules/autosave
if [ -e "$auto" ]; then
    packages_present+=("autosave")
else
    packages_left+=("autosave")
fi
Seq=~/Apps/epics/modules/Seq
if [ -e "$Seq" ]; then
    packages_present+=("seq")
else
    packages_left+=("seq")
fi
busy=~/Apps/epics/modules/busy
if [ -e "$busy" ]; then
    packages_present+=("busy")
else
    packages_left+=("busy")
fi
sscan=~/Apps/epics/modules/sscan
if [ -e "$sscan" ]; then
    packages_present+=("sscan")
else
    packages_left+=("sscan")
fi
calc=~/Apps/epics/modules/calc
if [ -e "$calc" ]; then
    packages_present+=("calc")
else
    packages_left+=("calc")
fi
area=~/Apps/epics/modules/areaDetector
if [ -e "$area" ]; then
    packages_present+=("areadetector")
else
    packages_left+=("areadetector")
fi
if [ ${#packages_present[@]} -eq 0 ]; then
    echo No packages present 
else
    echo Packages present 
    for str in ${packages_present[@]}; do
    	echo $str
    done
fi
if [ ${#packages_left[@]} -eq 0 ]; then
    echo No packages left  
else
    echo Packages left to install
    for str in ${packages_left[@]}; do
        echo $str
    done
    read -p "Do you want to install only remaining files or do a clean install?(y,n)" choice

    if [ "$choice" == 'y' ] || [ "$choice" == 'Y' ]; then
        for str in ${packages_left[@]}; do
            script="make${str}.sh"
            ./"$script"
            cd $basedir
        done
    else
		./epics_uninstall.sh
        for str in ${packages_left[@]}; do
        	script="make${str}.sh"
            ./"$script"
            cd $basedir
    	done
    fi
fi


