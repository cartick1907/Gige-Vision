#!/bin/bash
mkdir -p ~/Apps/epics
tar -zxvf base-7.0.3.tar.gz -C ~/Apps/epics
ln -s ~/Apps/epics/base-7.0.3/ ~/Apps/epics/base
sudo ln -s ~/Apps/epics/  /usr/local
ls -la ~ | grep ~/.bash_aliases
touch ~/.bash_aliases
echo "export EPICS_ROOT=/usr/local/epics" >> ~/.bash_aliases
EPICS_ROOT=/usr/local/epics
echo "export EPICS_BASE=${EPICS_ROOT}/base">> ~/.bash_aliases
EPICS_BASE=${EPICS_ROOT}/base
echo "export EPICS_HOST_ARCH=`${EPICS_BASE}/startup/EpicsHostArch`">> ~/.bash_aliases
EPICS_HOST_ARCH=`${EPICS_BASE}/startup/EpicsHostArch`
echo "export EPICS_BASE_BIN=${EPICS_BASE}/bin/${EPICS_HOST_ARCH}">> ~/.bash_aliases
EPICS_BASE_BIN=${EPICS_BASE}/bin/${EPICS_HOST_ARCH}
echo "export EPICS_BASE_LIB=${EPICS_BASE}/lib/${EPICS_HOST_ARCH}">> ~/.bash_aliases
EPICS_BASE_LIB=${EPICS_BASE}/lib/${EPICS_HOST_ARCH}
echo "if [ "" = "${LD_LIBRARY_PATH}" ]; then">> ~/.bash_aliases
echo "export LD_LIBRARY_PATH=${EPICS_BASE_LIB}">> ~/.bash_aliases
LD_LIBRARY_PATH=${EPICS_BASE_LIB}
echo "else">> ~/.bash_aliases
echo "export LD_LIBRARY_PATH=${EPICS_BASE_LIB}:${LD_LIBRARY_PATH}">> ~/.bash_aliases
echo "fi">> ~/.bash_aliases
echo "export PATH=${PATH}:${EPICS_BASE_BIN}" >> ~/.bash_aliases
sed -i 's/ = / "" = /g' ~/.bash_aliases
source ~/.bash_aliases
env | grep epics
cd ~/Apps/epics/base
make
