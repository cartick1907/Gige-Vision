#!/bin/bash
mkdir -p ~/Apps/epics
tar -zxvf base-3.16.1.tar.gz -C ~/Apps/epics
ln -s ~/Apps/epics/base-3.16.1 ~/Apps/epics/base
sudo ln -s ~/Apps/epics/  /usr/local
ls -la ~ | grep ~/.bash_aliases
cp .bash_aliases ~/.bash_aliases
env | grep epics
cd ~/Apps/epics/base
make
